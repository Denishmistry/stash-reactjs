import React from 'react';
import { BrowserRouter as Router,Switch,Route,Link} from "react-router-dom";
import data  from "../data.json";



class NavBar extends React.Component {
render(){
return(
<>
    <header class="custom-header">
        <div class="container ">
            <nav class="navbar navbar-expand-lg navbar-dark">
                <a class="navbar-brand" href="#!">
                    <img class="img-fluid" src="../images/logo.svg" alt="Logo" />
                </a>
                <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNavAltMarkup" aria-controls="navbarNavAltMarkup" aria-expanded="false" aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                </button>
                <div class="collapse navbar-collapse" id="navbarNavAltMarkup">
                    <div class="navbar-nav mx-auto">



                        <Link className="nav-item nav-link "  activeClassName="active"  to='/'>Home</Link>
                        <Link className="nav-item nav-link" activeClassName="active"  to='/platform'>PLATFORM</Link>
                         <Link className="nav-item nav-link" activeClassName="active" to='/technology'>TECHNOLOGY</Link>
                          <Link className="nav-item nav-link" activeClassName="active" to='/payment'>PAYMENT</Link>
                           <Link className="nav-item nav-link" activeClassName="active" to='/contact'>Contact</Link>
                        
                    </div>
                    <a class="theme-btn" href="#!">Request a Demo</a>
                </div>
            </nav>
        </div>
    </header>

</>
);
}
}
export default NavBar;