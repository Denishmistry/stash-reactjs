import React from 'react';
import { BrowserRouter as Router,Switch,Route,Link} from "react-router-dom";
import data  from "../data.json";

class HomeSlider extends React.Component {
render(){
return(
<>
          {
                    data.HomeBanner.map((bannertext) => {
                        return (    



            <div class="home">
                <div class="container">
                    <div class="row">
                        <div class="col-sm-12">
                            <div id="hero">
                                <div class="banner-text  text-center">
                                  <h1>{bannertext.hometext}</h1>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>


                                
                            );
                        })
                    }


</>
);
}
}
export default HomeSlider;